<!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
    <meta charset="utf-8" />
    <title>Register | BeytepeYemek.com</title>
    <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="<?php echo e(asset ('css/bootstrap.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset ('css/animate.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset ('css/font-awesome.min.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset ('css/font.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset ('css/app.css')); ?>" type="text/css" />
    <!--[if lt IE 9]>
    <script src="<?php echo e(asset ('js/ie/html5shiv.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/ie/respond.min.js')); ?>"></script>
    <script src="<?php echo e(asset ('js/ie/excanvas.js')); ?>"></script>
    <![endif]-->
</head>
<body>
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
    <div class="container aside-xxl">
        <a class="text-center block" href="index.html" style="color: #fb6b5b; font-weight: 200; font-size: 40px; margin-top: 20px;line-height: 1.0;" data-toggle="fullscreen">MAEOS <br><span style="font-size: 25px; color: rgb(101, 189, 119); font-weight: 900">KEOPS</span></a>
        <section class="panel panel-default bg-white m-t-lg">
            <header class="panel-heading text-center">
                <strong>Welcome to BeytepeYemek.com</strong>
            </header>

            <div class="card-body">
                <?php if(isset($url)): ?>
                    <form method="POST" action='<?php echo e(url("register/$url")); ?>' aria-label="<?php echo e(__('Register')); ?>">
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>

                                <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                    <div class="col-md-6">
                                        <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                        <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                    <div class="col-md-6">
                                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                    <div class="col-md-6">
                                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                                    <div class="col-md-6">
                                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                    </div>
                                </div>

                                <div class="form-group row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Register')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                    </form>
            </div>

        </section>
    </div>
</section>
<!-- footer -->
<footer id="footer">
    <div class="text-center padder">
        <p>
            <small>Copyright © <?php echo e(date('Y')); ?> MAEOS KEOPS</small>
        </p>
    </div>
</footer>
<!-- / footer -->

<script src="<?php echo e(asset ('js/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset ('js/bootstrap.js')); ?>"></script>
<!-- App -->
<script src="<?php echo e(asset ('js/app.js')); ?>"></script>
<script src="<?php echo e(asset ('js/app.plugin.js')); ?>"></script>
<script src="<?php echo e(asset ('js/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

</body>
</html>