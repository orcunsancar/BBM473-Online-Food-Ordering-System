<?php $__env->startSection('title'); ?>
	Print My Favourites
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox bg-white">
    <header class="header b-b b-light hidden-print">
        <button href="#" class="btn btn-sm btn-info pull-right" onClick="window.print();">Print</button>
        <p></p>
    </header>
    <section class="scrollable wrapper" id="print">
        <div class="row">
            <div class="col-xs-6">
                <h2 style="margin-top: 0px">MAEOS <b>KEOPS</b></h2>
                <p>Beytepe Campus, 06800 <br>
                    Çankaya / Ankara<br>
                    TURKEY <br>
                    (0312) 305 50 00
                </p>
            </div>
            <div class="col-xs-6 text-right">
                <h4></h4>
            </div>
        </div>
        <div class="well m-t" style="margin-bottom: 50px">
            <div class="row">
                <div class="col-xs-6">
                    <strong>TO:</strong>
                    <h4>
                        <?php echo e($scoreboard->name); ?></h4>
                    <h4> Product Name:
                        <?php echo e($scoreboard->product->product_name); ?></h4>
                    <p> Product Type:
                        <?php echo e($scoreboard->product->product_type); ?>

                    </p>
                    <b>Details: </b><?php echo e($scoreboard->product->product_details); ?>

                </div>
                <div class="col-xs-6 text-right">
                    <p class="h4">#<?php echo e($scoreboard->id); ?></p>
                    <h5>Price: <strong><?php echo e($scoreboard->product->price); ?> TL</strong></h5>

                    <p class="m-t m-b">My Favourites ID: <strong>#4</strong></p>
                </div>
            </div>
        </div>
        <div class="line"></div>

        <div class="row">
            <div class="col-xs-8">
                <p style="text-align: justify;"><i> BeytepeYemek.com </i></p><br><br>

                <p>BY ALISAR SANCAR</p>
            </div>
        </div>
    </section>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>