<?php $__env->startSection('title'); ?>
    All My Favourites
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox">
    <section class="scrollable padder">
        <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Home</a></li>
            <li class="active">Workset</li>
        </ul>
        <div class="m-b-md">
            <h3 class="m-b-none">My Favourites Data</h3>
        </div>
        <section class="panel panel-default">
            <header class="panel-heading">
                All My Favourites Data
                <button onClick ="$('#table').tableExport({type:'pdf',escape:'false',pdfFontSize:12,separator: ','});" class="btn btn-default btn-xs pull-right">PDF</i></button>
                <button onClick ="$('#table').tableExport({type:'csv',escape:'false'});" class="btn btn-default btn-xs pull-right">CSV</button>
                <button onClick ="$('#table').tableExport({type:'excel',escape:'false'});" class="btn btn-default btn-xs pull-right">Excel</i></button>
                <button onClick ="$('#table').tableExport({type:'sql',escape:'false',tableName:'scoreboards'});" class="btn btn-default btn-xs pull-right">SQL</i></button>
                <i class="fa fa-info-sign text-muted" data-toggle="tooltip" data-placement="bottom" data-title="ajax to load the data."></i>
            </header>
            <div class="table-responsive">
                <table class="table table-striped m-b-none" data-ride="datatables" id="table">
                    <thead>
                        <tr>
                            <th width="">ID</th>
                            <th width=""> My Favourites Name</th>
                            <th width=""> Product Name</th>
                            <th width=""> Product Type</th>
                            <th width="">Product Details</th>
                            <th width="">Product Price</th>

                            <th width="150px">Buttons</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $scoreboards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scoreboard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($scoreboard->id); ?></td>
                                <td><?php echo e($scoreboard->name); ?></td>
                                <td><?php echo e($scoreboard->product->product_name); ?></td>
                                <td><?php echo e($scoreboard->product->product_type); ?></td>
                                <td><?php echo e($scoreboard->product->product_details); ?></td>
                                <td><?php echo e($scoreboard->product->price); ?></td>

                                <td>
                                    <?php echo e(Form::open(['route' => ['scoreboard.destroy', $scoreboard->id], 'method' => 'delete', 'style'=>'display:inline-block'])); ?>

                                    <button type="submit" class="btn btn-sm btn-icon btn-danger" onclick="return confirm('Are you sure you want to delete this?')" ><i class="fa fa-trash-o"></i></button>
                                    <?php echo e(Form::close()); ?>

                                    <a href="<?php echo e(route('scoreboard.edit',$scoreboard->id)); ?>" class="btn btn-sm btn-icon btn-warning"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('scoreboard.show',$scoreboard->id)); ?>" class="btn btn-sm btn-icon btn-success"><i class="fa fa-print"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </section>
    </section>
 </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>