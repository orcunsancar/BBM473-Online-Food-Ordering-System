<?php $__env->startSection('title'); ?>
	Print Restaurants
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section class="vbox bg-white">
    <header class="header b-b b-light hidden-print">
        <button href="#" class="btn btn-sm btn-info pull-right" onClick="window.print();">Print</button>
        <p></p>
    </header>
    <section class="scrollable wrapper" id="print">
        <div class="row">
            <div class="col-xs-6">
                <h2 style="margin-top: 0px">MAEOS <b>KEOPS</b></h2>
                <p>Beytepe Campus, 06800 <br>
                    Çankaya / Ankara<br>
                    TURKEY <br>
                    (0312) 305 50 00
                </p>
            </div>
            <div class="col-xs-6 text-right">
                <h4></h4>
            </div>
        </div>
        <div class="well m-t" style="margin-bottom: 50px">
            <div class="row">
                <div class="col-xs-6">
                    <strong>TO:</strong>
                    <h4><?php echo e($restaurant->name); ?></h4>
                    <p>
                        <?php echo e($restaurant->city); ?>

                    </p>
                    <p>
                        <?php echo e($restaurant->district); ?>

                    </p>
                    <b>Phone: </b><?php echo e($restaurant->phone); ?>

                </div>
                <div class="col-xs-6 text-right">
                    <p class="h4">#<?php echo e($restaurant->id); ?></p>
                    <h5>Name: <strong><?php echo e($restaurant->name); ?></strong></h5>
                    <h5>City : <strong><?php echo e($restaurant->city); ?></strong><h5>
                     <h5>District: <strong><?php echo e($restaurant->district); ?></strong><h5>
                     <h5>Phone: <strong><?php echo e($restaurant->phone); ?></strong><h5>
                     <h5>Product: <strong><?php echo e($restaurant->product->product_name); ?></strong><h5>
                    <p class="m-t m-b">Restaurant ID: <strong>#4</strong></p>
                </div>
            </div>
        </div>
        <div class="line"></div>
        <div class="row">
            <div class="col-xs-8">
                <p style="text-align: justify;"><i> BeytepeYemek.com </i></p><br><br>

                <p>BY ALISAR SANCAR</p>
            </div>
        </div>
    </section>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>